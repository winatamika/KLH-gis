<?php
$mosConfig_locale_debug = 0;
$mosConfig_locale_use_gettext = 0;
$server="localhost";
$username="root";
$password="";
$database="gisppe";

define('APP_RUNNING',1);
define('ADMINPATH'		, 'gis-admin');//Sangat penting tolong disesuikan di setiap web
define('IMAGEPATH'		, 'images/gis_images/');//Sangat penting tolong disesuikan di setiap web
define('LIBPATH'		, 'libraries/');
define('MODULPATH'		, 'modules/');
define('SCRIPTPATH'		, 'script/');
?>